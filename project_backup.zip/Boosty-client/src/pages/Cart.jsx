import React from "react";

const Cart = () => {
  return (
    <div className="min-h-screen flex items-center justify-center">Cart</div>
  );
};

export default Cart;
